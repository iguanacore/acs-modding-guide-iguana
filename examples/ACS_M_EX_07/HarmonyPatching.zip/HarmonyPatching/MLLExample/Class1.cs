﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XiaWorld;
using HarmonyLib;

namespace MLLExample
{
    public class MLLExample
    {
        [HarmonyPatch(typeof(BodyPractice), "GetItemCost")]
        class MLLExamplePatch
        {
            static void Postfix(ref float __result, string part)
            {
                KLog.Dbg("[MLLExample] GetItemCost (" + __result + ")");
                __result = 1f;
            }
        }
    }
}
